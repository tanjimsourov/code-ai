# Configuration Reference

This document describes the most important environment variables and
settings that control the behaviour of the Code Editor backend.  All
settings are optional; sensible defaults are used when variables are
unset.  Values may be provided in a `.env` file or via the
deployment environment.

## API Key Enforcement

* **`CODE_EDITOR_REQUIRE_API_KEY`**: when set to a truthy value
  (`"1"`, `"true"`, `"yes"`, or `"on"`), all endpoints except
  liveness/readiness checks require the caller to present a valid API
  key.  Defaults to `false` for local development.

* **`CODE_EDITOR_DEFAULT_DAILY_QUOTA`**, **`CODE_EDITOR_DEFAULT_RPM_LIMIT`**:
  define the default daily quota and requests‑per‑minute limit applied
  to newly created API keys.  If unset, fall back to legacy
  variables `AI_DAILY_QUOTA_DEFAULT` and `AI_RPM_LIMIT_DEFAULT`.

## Public Surface Flags

These flags control which read‑only endpoints may be accessed without
authentication:

| Variable | Description | Default |
|---|---|---|
| `CODE_EDITOR_PUBLIC_MODEL_LISTING` | Expose `/models` without auth | `false` |
| `CODE_EDITOR_PUBLIC_PROVIDER_LISTING` | Expose `/providers` without auth | `false` |
| `CODE_EDITOR_PUBLIC_OPENAI_MODEL_LISTING` | Expose OpenAI `/models` without auth | `false` |
| `CODE_EDITOR_PUBLIC_METRICS` | Expose `/metrics` endpoint publicly | `false` |

Set these variables to `"1"`, `"true"`, `"yes"` or `"on"` to enable
the associated endpoint for anonymous users.

## Rate Limiting

Rate limits are enforced via custom throttles defined in
`code_editor/api/throttles.py`.  Each throttle has a scope and a default
rate expressed as `N/min`.  To override these values globally use
`REST_FRAMEWORK` settings in Django settings or define your own
`SimpleRateThrottle` subclasses.

## Provider Configuration

Provider settings (base URLs, models, API keys, headers, timeout and
retry behaviour) are derived from the `CODE_EDITOR_*` environment
variables with fallbacks to legacy `AI_*` variables.  See
`code_editor/services/config.py` for detailed logic and the available
variables per provider type.  Common variables include:

* `CODE_EDITOR_LOCAL_ENABLED`, `CODE_EDITOR_LOCAL_BASE_URL`, `CODE_EDITOR_LOCAL_MODEL`
* `CODE_EDITOR_FAST_ENABLED`, `CODE_EDITOR_STRONG_ENABLED`
* `CODE_EDITOR_OPENAI_COMPATIBLE_BASE_URL`, `CODE_EDITOR_OPENAI_COMPATIBLE_API_KEY`
* `CODE_EDITOR_EMBEDDINGS_ENABLED`, `CODE_EDITOR_EMBEDDINGS_PROVIDER`

## Logging Configuration

To enable prompt logging for debugging set `CODE_EDITOR_LOG_PROMPTS` to
a truthy value.  **Use with caution**: prompt logging may capture user
code and instructions and should never be enabled in untrusted
environments.

## Other Settings

* `CODE_EDITOR_MAX_CONTEXT_TOKENS`, `CODE_EDITOR_DEFAULT_MAX_OUTPUT_TOKENS`:
  adjust the token budgets used by the completion endpoints.
* `CODE_EDITOR_AGENT_*`: control the behaviour of the autonomous
  agent loop used by experimental workflows.

Refer to the inline documentation in `services/config.py` for more
configuration helpers and defaults.
