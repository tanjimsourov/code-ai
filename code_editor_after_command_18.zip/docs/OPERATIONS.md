# Operational Guide for the Code Editor Backend

This document provides high‑level guidance for administrators operating
the Code Editor backend in production.  It covers common tasks such as
creating and revoking API keys, monitoring quotas and metrics, and
using the Django admin interface to inspect tasks, artifacts and
repository state.

## API Key Management

API keys are stored in the `CodeEditorApiKey` model.  To create a new
key you can use Django admin or call the appropriate management command
(if available) which returns the raw key once.  Keep this value
secure; only the hashed key is stored.  The admin list view exposes
the key `prefix`, daily quota and RPM limit, activation status and
last used timestamp.  You may revoke a key by toggling its
`is_active` flag or calling the `revoke()` method from the shell.

Quota defaults for new keys can be configured via environment
variables (see `docs/CONFIGURATION.md`).  To monitor usage per key use
the `CodeEditorRequestLog` and Prometheus metrics.  Quota and rate
limit violations result in HTTP 429 responses and are counted via
Prometheus counters.

## Monitoring and Metrics

The backend exposes a `/metrics` endpoint that exports Prometheus
counters and histograms for request counts, latencies, token usage and
provider health.  Access to this endpoint is controlled by the
`CODE_EDITOR_PUBLIC_METRICS` flag.  Internal services may scrape this
endpoint to populate dashboards and alerts.

Provider health is tracked in the `ProviderHealth` model and updated
automatically by internal instrumentation.  Use the admin to inspect
provider status and response times or query the model directly from
the Django shell.

## Admin Console

The Django admin has been extended to provide visibility into all
operational data structures:

* **Projects, repositories and ingestion jobs**: view project
  configurations, repository sync status, ingestion progress and
  indexing errors.
* **Tasks and steps**: track task progress, current stage, apply
  modes and failure reasons.  Each task shows its steps, plan nodes,
  selected files, candidate patches, scores, validation runs, test
  runs, snapshots and artifacts.  Use filters and search fields to
  narrow results.  Large logs and diffs are truncated in list views.
* **API keys and request logs**: audit usage patterns, monitor which
  endpoints are hit most frequently and identify failing requests.

Only staff or superuser accounts should access the admin.  Do not
grant admin privileges to untrusted users.

## Retrieval Endpoint Considerations

The retrieval endpoints (`/search/` and `/files/`) now require
clients to specify one or more `repository_ids`.  This prevents
unbounded cross‑project searches and enforces tenant isolation.  If
`repository_ids` is omitted the endpoints return a 400 error.

## Patch and Task Management

Applying or reverting patches is a sensitive operation.  The
`/patch/apply/` endpoint requires the `CanApprovePatch` permission and
the `/patch/revert/` endpoint requires `CanMutateRepository`.  Only
authenticated users or API keys with the appropriate roles should
perform these actions.  Similarly, task creation and cancellation
trigger asynchronous workflows and should be rate limited.

## Background Tasks and Workers

Long‑running operations such as ingestion, indexing, retrieval and
autonomous task execution are orchestrated via Celery tasks (see
`code_editor/tasks.py`).  Ensure worker processes are running and
configured to execute tasks from the correct queues.  Operator
commands under `code_editor/management/commands` can be used to
inspect provider health, synchronize repositories and perform smoke
checks.

### Cache and Embedding Maintenance

Several internal caches are used to accelerate frequent lookups for
model registries, provider health, repository statistics, code maps,
context packs and retrieval results.  These caches must be
invalidated when underlying data changes; otherwise stale data may be
returned.  A helper service (`CacheHelper`) centralises invalidation
methods.  To clear caches at runtime use the management command:

```bash
python manage.py code_editor_invalidate_caches --cache model_registry
```

Omit `--cache` to clear all known caches.  Use the `--dry-run`
flag to see which caches would be cleared without performing the
operation.

Embeddings can drift out of date when code changes.  To rebuild
embeddings for a specific repository or all repositories run:

```bash
python manage.py code_editor_rebuild_embeddings --repository-id=<UUID>
```

Omit `--repository-id` to rebuild embeddings for every indexed
repository.  Use `--limit` to bound the number of files processed
per repository and `--dry-run` to preview the operation.  Embedding
rebuilds run synchronously and may take considerable time on large
repositories.

A comprehensive installation check can be run via
`code_editor_validate_install` which compiles all Python files,
verifies the migration graph has a single leaf and exercises a smoke
check.  This command is useful after deploying code changes to
ensure that the system will start correctly.

Old artifacts and snapshots consume disk space.  The
`code_editor_prune_artifacts` command prunes `Artifact` records
older than a configurable number of days and optionally deletes
associated files from disk.  Use the `--remove-files` flag to
delete files in addition to database records, and `--dry-run` to
preview the deletions.

## Management Commands Reference

The following management commands are available to administrators. All
commands can be executed via `python manage.py <command> --help` for
additional options.

| Command | Description |
|--------|-------------|
| **code_editor_smoke_check** | Imports core modules, checks migration leaf nodes and lists available providers. |
| **check_code_editor_providers** | Lists configured providers and their health status without making paid API calls. |
| **show_code_editor_model_registry** | Displays the resolved model registry for each role, including provider and model names. |
| **sync_code_editor_repository** | Synchronises a repository from its remote source. |
| **reindex_code_editor_repository** | Indexes or reindexes a repository by reading files and updating the `IndexedFile` and `CodeChunk` tables. |
| **cleanup_code_editor_workspaces** | Removes old task workspace directories under the task storage root. |
| **code_editor_invalidate_caches** | Clears one or more internal caches (model registry, provider health, repository stats, code map, context pack, retrieval results). |
| **code_editor_rebuild_embeddings** | Rebuilds embeddings for a repository or all repositories. |
| **code_editor_validate_install** | Runs compile checks, smoke checks, migration leaf verification and optional provider health checks to validate an installation. |
| **code_editor_prune_artifacts** | Removes artifacts older than a specified age and optionally deletes associated files from disk. |
| **code_editor_health_report** | Generates a health report summarising provider status, migrations and cache connectivity (see `docs/DEPLOYMENT.md`). |
| **code_editor_sync_upstream_sources** | Fetches allow‑listed upstream metadata and prepares candidate patches for review. |
