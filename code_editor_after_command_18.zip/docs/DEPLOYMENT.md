# Deployment Guide

This document describes how to deploy the Code Editor backend in a production environment.

## Application Setup

1. **Django Settings** – ensure `code_editor` is listed in `INSTALLED_APPS` and the REST framework is configured. Use `REST_FRAMEWORK` settings to customise throttling and authentication. For example:

```python
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': ['code_editor.auth.CodeEditorApiKeyAuthentication'],
    'DEFAULT_PERMISSION_CLASSES': ['code_editor.permissions.CodeEditorApiKeyPermission'],
    'DEFAULT_THROTTLE_CLASSES': [
        'code_editor.api.throttles.AIThrottle',
        'code_editor.api.throttles.TaskMutationThrottle',
        'code_editor.api.throttles.RepoMutationThrottle',
    ],
}
```

2. **URL Configuration** – mount the API under a prefix (e.g. `/api/code-editor/`) as shown in the installation guide. The health endpoints `/health/live` and `/health/ready` can be exposed publicly via a load balancer or orchestrator.

3. **Cache Backend** – configure a cache backend (Redis or memcached) for throttling and caching. In `settings.py`:

```python
CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'code_editor_cache',
    }
}
```

In production, replace `LocMemCache` with a network cache (e.g. Redis).

4. **Celery & Workers** – asynchronous tasks (ingestion, indexing, validation, autonomous agent) use Celery when `CODE_EDITOR_TASK_USE_CELERY` is true. Configure a broker and result backend; start one or more workers listening on the `code_editor` queue.

## Storage

 - **Repository Root**: remote repositories are cloned under the `Repository.root_path` field. For local repositories, set `CODE_EDITOR_REPOSITORY_STORAGE_ROOT` to constrain accessible directories.  The legacy variable `CODE_EDITOR_REPOSITORY_ROOT` is still accepted but should be migrated to the new name.
- **Task Workspace Root**: task execution uses per‑task workspaces under `CODE_EDITOR_TASK_STORAGE_ROOT` (defaults to `/tmp/code_editor_tasks`). Ensure this directory has sufficient disk space and is regularly pruned via the `cleanup_code_editor_workspaces` command.
- **Artifact Storage**: artifacts and snapshots are stored relative to `CODE_EDITOR_TASK_STORAGE_ROOT`. Use the `code_editor_prune_artifacts` command to remove stale artifacts.

## Database

- Use PostgreSQL. For retrieval features, enable the `vector` extension and install the `pgvector` Python package.
- Apply migrations on deploy. Monitor the migration graph for conflicts and ensure only one migration leaf exists.

## Monitoring & Metrics

- The `/metrics/` endpoint exposes Prometheus metrics including request counts, latencies, token usage and provider health. Control public access via `CODE_EDITOR_PUBLIC_METRICS`.
- The `code_editor_health_report` management command provides a CLI summary of provider status, database migrations and cache health.
- Use the Django admin to inspect tasks, repositories, snapshots and logs.

## Security Considerations

- Enforce API keys in production by setting `CODE_EDITOR_REQUIRE_API_KEY=true`. Adjust quota defaults via environment variables.
- Limit public endpoints via `CODE_EDITOR_PUBLIC_*` flags.
- Configure TLS/HTTPS at the load balancer.
- Never set `CODE_EDITOR_LOG_PROMPTS=true` in untrusted environments.

## Upstream Self‑Update Governance

The `code_editor_sync_upstream_sources` command fetches metadata from allow‑listed upstream sources and prepares candidate patches. It never auto‑merges upstream code; instead it records metadata and creates a task requiring manual approval. See `docs/SECURITY.md` for details.

## Deployment Checklist

- [ ] All migrations applied
- [ ] `.env` configured with providers, quotas and flags
- [ ] Cache backend available
- [ ] Celery workers running (if async)
- [ ] API keys created
- [ ] Health and metrics endpoints reachable
- [ ] Upstream sync governance configured