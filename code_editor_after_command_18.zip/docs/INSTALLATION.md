# Installation Guide

This document explains how to install and integrate the Code Editor backend into an existing Django project.

## Prerequisites

- Python 3.11 or later
- Django 4.x
- A PostgreSQL database (for retrieval features and optional pgvector extension)
- Optional: Redis or other cache backend (for rate limiting and caching)
- Optional: Celery and a message broker (for asynchronous task execution)

## Quick Start

1. **Install dependencies**

   ```sh
   # If using a published package:
   pip install code_editor
   # Or, if working from a local checkout:
   pip install -r requirements.txt
   ```

   For retrieval features (embeddings and rerank) install extras:

   ```sh
   pip install pgvector psycopg
   ```

2. **Add `code_editor` to `INSTALLED_APPS`** in your `settings.py`:

   ```python
   INSTALLED_APPS = [
       # ... your existing apps ...
       'rest_framework',  # ensure DRF is installed
       'code_editor',
   ]
   ```

3. **Include the API routes** in your project’s `urls.py`:

   ```python
   from django.urls import include, path

   urlpatterns = [
       # … your other routes …
       path('api/code-editor/', include('code_editor.api.urls')),
   ]
   ```

4. **Apply migrations**:

   ```sh
   python manage.py makemigrations code_editor
   python manage.py migrate
   ```

   The code editor stores metadata in its own tables. When using retrieval features, ensure the `vector` extension is enabled in PostgreSQL:

   ```sql
   CREATE EXTENSION IF NOT EXISTS vector;
   ```

5. **Configure environment variables.**

   Create a `.env` file based on `.env.example` and set appropriate provider URLs, API keys, storage paths and flags. See `docs/CONFIGURATION.md` for a full reference.

6. **Create an API key** (recommended for production):

   Set `CODE_EDITOR_REQUIRE_API_KEY=true` and use the Django admin to create a `CodeEditorApiKey`. Assign daily quota and RPM limits appropriate for your usage. Omit this step to run in single‑user mode.

7. **(Optional) Configure Celery workers**:

   To offload ingestion and agent tasks, configure a Celery broker (e.g. Redis or RabbitMQ) and start workers:

   ```sh
   celery -A yourproject worker -Q code_editor -l INFO
   ```

   Enable asynchronous mode by setting `CODE_EDITOR_TASK_USE_CELERY=true`.

## Zero‑Cost Local Provider Setup

You can run the code editor entirely with local models and avoid paid APIs:

- **Ollama**: install [Ollama](https://ollama.ai/) and run `ollama serve`. Set `CODE_EDITOR_OLLAMA_BASE_URL=http://localhost:11434`, choose a model such as `qwen2.5-coder-7b-instruct` and set `CODE_EDITOR_OLLAMA_MODEL` accordingly.
- **LocalAI or llama.cpp**: run a compatible server and set `CODE_EDITOR_LOCAL_BASE_URL` and `CODE_EDITOR_LOCAL_MODEL`.
- **vLLM / LM Studio**: run the server in OpenAI compatibility mode and set `CODE_EDITOR_VLLM_BASE_URL` and `CODE_EDITOR_VLLM_MODEL`.

Set `CODE_EDITOR_EMBEDDINGS_ENABLED=false` and `CODE_EDITOR_RERANK_ENABLED=false` if you are not using embeddings or rerank.

## Next Steps

- Read `docs/CONFIGURATION.md` for environment variable descriptions.
- See `docs/DEPLOYMENT.md` for production considerations such as caching, storage, Celery and health endpoints.