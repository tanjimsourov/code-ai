# Security Guide for Code Editor API

The Code Editor backend exposes a powerful API for AI‑assisted code editing
and autonomous task execution.  Running this backend in production
requires careful configuration to ensure sensitive data and operations
remain protected.  This guide summarizes the key security features and
controls added in Command 14 and how to use them.

## Authentication and API Keys

By default the backend requires callers to present a valid API key on
every endpoint except the minimal health checks (`/health/live` and
`/health/ready`).  API keys are stored hashed and are associated with
quota limits (requests per day and requests per minute).  Set
`CODE_EDITOR_REQUIRE_API_KEY=1` in your environment to enforce
authentication.  Raw API keys are only returned at creation time and
must not be logged or exposed.

The `CodeEditorApiKeyPermission` class enforces authentication and
delegates quota enforcement to `QuotaService`.  Extended permissions
such as `PublicModelListingPermission`, `PublicProviderListingPermission`
and `PublicOpenAIModelListingPermission` allow specific read‑only
endpoints to be exposed publicly when explicitly enabled via
environment variables.

## Public Surface Flags

Several environment variables control which endpoints may be accessed
without authentication:

* `CODE_EDITOR_PUBLIC_MODEL_LISTING`: if set to a truthy value, the
  `/models` endpoint becomes public.  Otherwise it requires an API key.
* `CODE_EDITOR_PUBLIC_PROVIDER_LISTING`: controls public access to
  `/providers`.
* `CODE_EDITOR_PUBLIC_OPENAI_MODEL_LISTING`: controls public access to
  the OpenAI‑compatible `/models` endpoint.
* `CODE_EDITOR_PUBLIC_METRICS`: allows the `/metrics` endpoint to be
  exposed without authentication (not recommended).

If these flags are unset or false, the associated endpoints require
authentication and are subject to rate and quota limits.

## Rate Limiting and Quotas

Custom throttles defined in `code_editor/api/throttles.py` apply per‑
scope rate limits.  AI‑generation endpoints (chat, completion, edit,
embedding, rerank, infill and their OpenAI equivalents) use the
`AIThrottle` which by default allows 60 requests per minute per API key.
Mutation endpoints (task creation, repository changes, patch apply and
revert) can be further throttled using `TaskMutationThrottle` and
`RepoMutationThrottle`.

The `QuotaService` enforces daily quotas and per‑minute request limits
for each API key.  When a limit is exceeded the service raises an
exception which results in a `429 Too Many Requests` response.

## Endpoint Hardening

All endpoints now declare explicit `permission_classes` rather than
falling back to the default `AllowAny`.  AI generation and retrieval
endpoints additionally apply throttles and perform quota checks.  The
retrieval endpoints require the caller to specify one or more
`repository_ids` to prevent unbounded cross‑project searches.

Patch management endpoints are protected by dedicated permissions:
`CanApprovePatch` for applying generated patches and
`CanMutateRepository` for reverting patches.

## Multi‑tenant Scoping

List endpoints for tasks, repositories and projects must be scoped to
the caller’s organisation or API key.  In the current implementation
this is enforced by requiring the client to specify repository or
project identifiers and by applying API‑key authentication.  Further
multi‑tenant isolation may be added in future revisions.

## Admin Console

The Django admin has been extended to register all operational
models (tasks, steps, plan nodes, selected files, candidate patches,
scores, validation runs, test runs, snapshots and artifacts).  List
views expose only small sets of fields and truncate large text to
avoid rendering megabytes of logs.  Sensitive attributes such as raw
API keys, patch contents and error details are marked read‑only.

## Logging and Observability

Request logs (via `CodeEditorRequestLog`) record metadata about each
call while avoiding the storage of raw prompts, API keys or secrets.
Structured logging and Prometheus metrics are emitted through the
`observability` package.  Operators can monitor rate limit and quota
violations via these metrics.

## Upstream Self‑Update Governance

Integrating upstream open‑source projects requires strict governance. The
`code_editor_sync_upstream_sources` management command fetches metadata
from allow‑listed sources and records the current versions, licence
information and change summaries. When an upstream update is detected
the service creates a candidate patch (stored as a `CandidatePatch` and
associated `Task`) which must be reviewed and approved by a human
operator. The system **never** applies upstream changes automatically.
Administrators should examine the candidate patch via the patch review
workflow (`/patch/apply/`) and decide whether to accept, modify or
reject it. Rollback metadata is also recorded to facilitate reverting
changes if necessary.
