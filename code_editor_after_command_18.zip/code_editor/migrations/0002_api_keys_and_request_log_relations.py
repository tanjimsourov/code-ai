from django.conf import settings
from django.db import migrations, models
import django.core.validators
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('code_editor', '0001_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='CodeEditorApiKey',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(max_length=255)),
                ('key_hash', models.CharField(max_length=64, unique=True)),
                ('prefix', models.CharField(db_index=True, max_length=16)),
                ('daily_quota', models.IntegerField(default=1000, validators=[django.core.validators.MinValueValidator(0)])),
                ('rpm_limit', models.IntegerField(default=60, validators=[django.core.validators.MinValueValidator(1)])),
                ('is_active', models.BooleanField(default=True)),
                ('last_used_at', models.DateTimeField(blank=True, null=True)),
                ('revoked_at', models.DateTimeField(blank=True, null=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('created_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='code_editor_api_keys', to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'db_table': 'code_editor_api_key',
                'ordering': ['-created_at'],
            },
        ),
        migrations.AddIndex(
            model_name='codeeditorapikey',
            index=models.Index(fields=['prefix'], name='code_editor_prefix_53c8eb_idx'),
        ),
        migrations.AddIndex(
            model_name='codeeditorapikey',
            index=models.Index(fields=['is_active'], name='code_editor_is_acti_076db1_idx'),
        ),
        migrations.AddIndex(
            model_name='codeeditorapikey',
            index=models.Index(fields=['created_at'], name='code_editor_created_f1fb17_idx'),
        ),
        migrations.AddField(
            model_name='codeeditorrequestlog',
            name='api_key',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='request_logs', to='code_editor.codeeditorapikey'),
        ),
        migrations.AddField(
            model_name='codeeditorrequestlog',
            name='user',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='code_editor_request_logs', to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddIndex(
            model_name='codeeditorrequestlog',
            index=models.Index(fields=['api_key'], name='code_editor_api_key_2e9e9f_idx'),
        ),
        migrations.AddIndex(
            model_name='codeeditorrequestlog',
            index=models.Index(fields=['user'], name='code_editor_user_id_3e66b7_idx'),
        ),
    ]
