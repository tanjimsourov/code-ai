"""Add performance indexes for common lookup fields.

This migration introduces additional database indexes on high‑cardinality or
frequently filtered fields to improve query performance for common API
operations.  Indexes are added to project names, repository URL/branch/VCS
provider/commit SHA, task approval statuses and apply modes, and candidate
patch approval and apply modes.
"""

from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('code_editor', '0005_task_lifecycle'),
    ]

    operations = [
        # Project name index
        migrations.AddIndex(
            model_name='project',
            index=models.Index(fields=['name'], name='code_editor_proj_name_idx'),
        ),

        # Repository indexes
        migrations.AddIndex(
            model_name='repository',
            index=models.Index(fields=['url'], name='code_editor_repo_url_idx'),
        ),
        migrations.AddIndex(
            model_name='repository',
            index=models.Index(fields=['branch'], name='code_editor_repo_branch_idx'),
        ),
        migrations.AddIndex(
            model_name='repository',
            index=models.Index(fields=['vcs_provider'], name='code_editor_repo_vcs_idx'),
        ),
        migrations.AddIndex(
            model_name='repository',
            index=models.Index(fields=['commit_sha'], name='code_editor_repo_commit_idx'),
        ),

        # TaskRun indexes
        migrations.AddIndex(
            model_name='taskrun',
            index=models.Index(fields=['approval_status'], name='code_editor_taskrun_approval_idx'),
        ),
        migrations.AddIndex(
            model_name='taskrun',
            index=models.Index(fields=['effective_apply_mode'], name='code_editor_taskrun_eff_apply_idx'),
        ),
        migrations.AddIndex(
            model_name='taskrun',
            index=models.Index(fields=['requested_apply_mode'], name='code_editor_taskrun_req_apply_idx'),
        ),

        # CandidatePatch indexes
        migrations.AddIndex(
            model_name='candidatepatch',
            index=models.Index(fields=['approval_status'], name='code_editor_candidate_patch_approval_idx'),
        ),
        migrations.AddIndex(
            model_name='candidatepatch',
            index=models.Index(fields=['apply_mode_effective'], name='code_editor_candidate_patch_eff_apply_idx'),
        ),
    ]