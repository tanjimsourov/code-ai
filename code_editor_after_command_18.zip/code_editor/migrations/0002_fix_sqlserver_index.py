# Generated migration to fix SQL Server compatibility issue

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('code_editor', '0001_initial'),
    ]

    operations = [
        # Remove the problematic index on file_path TextField
        migrations.RemoveIndex(
            model_name='indexedfile',
            name='code_editor_file_pa_0c2451_idx',
        ),
        # Alter the field from TextField to CharField to make it indexable in SQL Server
        migrations.AlterField(
            model_name='indexedfile',
            name='file_path',
            field=models.CharField(max_length=1000, help_text='Relative file path in repository'),
        ),
        # Re-add the index on the CharField
        migrations.AddIndex(
            model_name='indexedfile',
            index=models.Index(fields=['file_path'], name='code_editor_file_pa_0c2451_idx'),
        ),
    ]
