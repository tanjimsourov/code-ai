from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('code_editor', '0002_fix_sqlserver_index'),
    ]

    operations = [
        migrations.AddField(
            model_name='codechunk',
            name='symbol_name',
            field=models.CharField(
                max_length=255,
                null=True,
                blank=True,
                help_text='Function or class name if applicable',
            ),
        ),
        migrations.AddIndex(
            model_name='codechunk',
            index=models.Index(fields=['symbol_name'], name='code_editor_symb_name_idx'),
        ),
    ]