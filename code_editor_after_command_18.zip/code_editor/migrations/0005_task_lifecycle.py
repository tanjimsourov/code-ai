from django.db import migrations, models
import django.db.models.deletion
from django.conf import settings


class Migration(migrations.Migration):
    """
    Migration adding new fields to support advanced task lifecycle management.

    This migration introduces failure_reason, apply mode fields and approval
    metadata on TaskRun, per-candidate apply/approval fields on CandidatePatch,
    and an exit_code field on TestRun.  It does not modify existing data but
    expands the schema for richer workflow support.
    """

    dependencies = [
        ('code_editor', '0004_merge_migrations'),
    ]

    operations = [
        # TaskRun fields
        migrations.AddField(
            model_name='taskrun',
            name='failure_reason',
            field=models.CharField(
                max_length=64,
                blank=True,
                help_text='Categorical failure reason when the task does not complete successfully',
            ),
        ),
        migrations.AddField(
            model_name='taskrun',
            name='requested_apply_mode',
            field=models.CharField(
                max_length=32,
                choices=[
                    ('suggest', 'Suggest'),
                    ('draft_patch', 'Draft Patch'),
                    ('apply_to_workspace', 'Apply to Workspace'),
                    ('auto_apply_if_validated', 'Auto Apply If Validated'),
                    ('manual_approval_required', 'Manual Approval Required'),
                ],
                default='suggest',
                help_text='Requested apply mode for generated patches',
            ),
        ),
        migrations.AddField(
            model_name='taskrun',
            name='effective_apply_mode',
            field=models.CharField(
                max_length=32,
                choices=[
                    ('suggest', 'Suggest'),
                    ('draft_patch', 'Draft Patch'),
                    ('apply_to_workspace', 'Apply to Workspace'),
                    ('auto_apply_if_validated', 'Auto Apply If Validated'),
                    ('manual_approval_required', 'Manual Approval Required'),
                ],
                default='suggest',
                help_text='Effective apply mode used after applying policy decisions',
            ),
        ),
        migrations.AddField(
            model_name='taskrun',
            name='approval_status',
            field=models.CharField(
                max_length=16,
                choices=[('pending', 'Pending'), ('approved', 'Approved'), ('rejected', 'Rejected')],
                default='pending',
                help_text='Approval status for manual review of the task result',
            ),
        ),
        migrations.AddField(
            model_name='taskrun',
            name='approved_by',
            field=models.ForeignKey(
                related_name='approved_tasks',
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                to=settings.AUTH_USER_MODEL,
                blank=True,
            ),
        ),
        migrations.AddField(
            model_name='taskrun',
            name='approved_at',
            field=models.DateTimeField(null=True, blank=True),
        ),
        migrations.AddField(
            model_name='taskrun',
            name='rejected_by',
            field=models.ForeignKey(
                related_name='rejected_tasks',
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                to=settings.AUTH_USER_MODEL,
                blank=True,
            ),
        ),
        migrations.AddField(
            model_name='taskrun',
            name='rejected_at',
            field=models.DateTimeField(null=True, blank=True),
        ),
        migrations.AddField(
            model_name='taskrun',
            name='rejection_reason',
            field=models.TextField(blank=True),
        ),
        # CandidatePatch fields
        migrations.AddField(
            model_name='candidatepatch',
            name='apply_mode_requested',
            field=models.CharField(
                max_length=32,
                choices=[
                    ('suggest', 'Suggest'),
                    ('draft_patch', 'Draft Patch'),
                    ('apply_to_workspace', 'Apply to Workspace'),
                    ('auto_apply_if_validated', 'Auto Apply If Validated'),
                    ('manual_approval_required', 'Manual Approval Required'),
                ],
                default='suggest',
                help_text='Requested apply mode for this candidate patch',
            ),
        ),
        migrations.AddField(
            model_name='candidatepatch',
            name='apply_mode_effective',
            field=models.CharField(
                max_length=32,
                choices=[
                    ('suggest', 'Suggest'),
                    ('draft_patch', 'Draft Patch'),
                    ('apply_to_workspace', 'Apply to Workspace'),
                    ('auto_apply_if_validated', 'Auto Apply If Validated'),
                    ('manual_approval_required', 'Manual Approval Required'),
                ],
                default='suggest',
                help_text='Effective apply mode for this candidate after policy evaluation',
            ),
        ),
        migrations.AddField(
            model_name='candidatepatch',
            name='approval_status',
            field=models.CharField(
                max_length=16,
                choices=[('pending', 'Pending'), ('approved', 'Approved'), ('rejected', 'Rejected')],
                default='pending',
                help_text='Approval status for this candidate patch',
            ),
        ),
        migrations.AddField(
            model_name='candidatepatch',
            name='approved_by',
            field=models.ForeignKey(
                related_name='approved_candidate_patches',
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                to=settings.AUTH_USER_MODEL,
                blank=True,
            ),
        ),
        migrations.AddField(
            model_name='candidatepatch',
            name='approved_at',
            field=models.DateTimeField(null=True, blank=True),
        ),
        migrations.AddField(
            model_name='candidatepatch',
            name='rejected_by',
            field=models.ForeignKey(
                related_name='rejected_candidate_patches',
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                to=settings.AUTH_USER_MODEL,
                blank=True,
            ),
        ),
        migrations.AddField(
            model_name='candidatepatch',
            name='rejected_at',
            field=models.DateTimeField(null=True, blank=True),
        ),
        migrations.AddField(
            model_name='candidatepatch',
            name='rejection_reason',
            field=models.TextField(blank=True),
        ),
        # TestRun exit_code field
        migrations.AddField(
            model_name='testrun',
            name='exit_code',
            field=models.IntegerField(null=True, blank=True),
        ),
    ]