"""Add composite indexes for improved query performance.

This migration adds several composite indexes on frequently queried fields to
improve performance for request logging, repository state, indexed files,
code chunks, task runs, candidate patches, validation runs and test runs.
It mirrors the changes introduced in Command 15.
"""

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('code_editor', '0006_performance_indexes'),
    ]

    operations = [
        # Request log indexes
        migrations.AddIndex(
            model_name='codeeditorrequestlog',
            index=models.Index(fields=['api_key', 'created_at'], name='reqlog_api_key_created_at_idx'),
        ),
        migrations.AddIndex(
            model_name='codeeditorrequestlog',
            index=models.Index(fields=['provider', 'status', 'created_at'], name='reqlog_provider_status_created_idx'),
        ),

        # Repository composite index
        migrations.AddIndex(
            model_name='repository',
            index=models.Index(fields=['project', 'sync_status', 'indexing_status'], name='repo_proj_sync_index_idx'),
        ),

        # IndexedFile composite indexes
        migrations.AddIndex(
            model_name='indexedfile',
            index=models.Index(fields=['repository', 'language', 'indexed_at'], name='idxfile_repo_lang_idxed_idx'),
        ),
        migrations.AddIndex(
            model_name='indexedfile',
            index=models.Index(fields=['repository', 'file_path'], name='idxfile_repo_file_idx'),
        ),

        # CodeChunk composite index
        migrations.AddIndex(
            model_name='codechunk',
            index=models.Index(fields=['indexed_file', 'chunk_type', 'chunk_index'], name='chunk_file_type_order_idx'),
        ),

        # Additional CodeChunk index for symbol lookup on a per-file basis
        migrations.AddIndex(
            model_name='codechunk',
            index=models.Index(fields=['indexed_file', 'symbol_name'], name='chunk_file_symbol_idx'),
        ),

        # TaskRun composite index
        migrations.AddIndex(
            model_name='taskrun',
            index=models.Index(fields=['repository', 'status', 'created_at'], name='taskrun_repo_status_created_idx'),
        ),

        # CandidatePatch composite index
        migrations.AddIndex(
            model_name='candidatepatch',
            index=models.Index(fields=['task', 'status', 'selected_at'], name='candidate_task_status_selected_idx'),
        ),

        # ValidationRun composite index
        migrations.AddIndex(
            model_name='validationrun',
            index=models.Index(fields=['task', 'status', 'created_at'], name='validation_task_status_created_idx'),
        ),

        # TestRun composite index
        migrations.AddIndex(
            model_name='testrun',
            index=models.Index(fields=['task', 'status', 'created_at'], name='testrun_task_status_created_idx'),
        ),
    ]