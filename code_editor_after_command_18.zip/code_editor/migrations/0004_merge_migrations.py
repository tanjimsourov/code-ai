"""Merge migrations for ``code_editor`` app.

This migration resolves multiple ``0002`` migration branches by
introducing a common ancestor for both ``0002_api_keys_and_request_log_relations``
and ``0003_add_symbol_name_to_codechunk``.  It does not perform any
schema changes; its sole purpose is to unify the migration graph so
that subsequent migrations apply cleanly in all environments.

As no operations are defined, applying this migration will not alter
the database schema.
"""

from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('code_editor', '0002_api_keys_and_request_log_relations'),
        ('code_editor', '0003_add_symbol_name_to_codechunk'),
    ]

    operations: list = []