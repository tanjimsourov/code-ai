"""
Management command to synchronise allow‑listed upstream sources.

This command uses the ``UpstreamSyncService`` to fetch metadata from upstream
sources and prepare candidate patches. It never applies upstream changes
directly. Operators should review generated tasks and candidate patches
via the patch review workflow.

Example usage::

    python manage.py code_editor_sync_upstream_sources
"""

from django.core.management.base import BaseCommand
from ...services.upstream_sync_service import UpstreamSyncService


class Command(BaseCommand):
    help = "Synchronise allow‑listed upstream sources and prepare update candidates"

    def handle(self, *args, **options) -> None:
        service = UpstreamSyncService()
        service.sync_all()
        self.stdout.write(self.style.SUCCESS("Upstream sync completed"))