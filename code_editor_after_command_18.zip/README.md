# Code Editor

The Code Editor is a Django application that provides AI‑assisted code generation, refactoring and autonomous bug repair. It integrates with model providers such as Ollama, LocalAI, vLLM/LM Studio and any OpenAI‑compatible API to perform chat, completion, edit, infill, embeddings and reranking tasks. Retrieval and context search are backed by a PostgreSQL database with optional vector search via pgvector.

> **Note:** This package is provided as a reference implementation. It is not a drop‑in replacement for your development workflow and should be deployed cautiously. Always review patches before applying them to your repositories and secure the API using API keys in production.

## Quick install

1. Install dependencies and the code editor module.
2. Add `code_editor` to `INSTALLED_APPS` and include its URLs under a prefix.
3. Apply migrations and configure environment variables via `.env`.
4. Create API keys and configure providers.
5. (Optional) Start Celery workers for asynchronous tasks.

For detailed instructions see `docs/INSTALLATION.md`.

## Zero‑cost local provider setup

You can run the code editor without paid APIs by using local providers such as Ollama or LocalAI. See `docs/INSTALLATION.md` for examples.

## Documentation

- Configuration: `docs/CONFIGURATION.md`
- Deployment: `docs/DEPLOYMENT.md`
- Security: `docs/SECURITY.md`
- Operations & management commands: `docs/OPERATIONS.md`
- Task execution lifecycle: `docs/TASK_EXECUTION.md`
- Patch review workflow: `docs/PATCH_REVIEW.md`

## Readiness checklist

Before going to production ensure that:

- [ ] All migrations are applied and the migration graph has a single leaf.
- [ ] API keys are required via `CODE_EDITOR_REQUIRE_API_KEY`.
- [ ] Quotas and throttle rates are configured appropriately.
- [ ] Public endpoints are disabled unless intentionally exposed.
- [ ] Cache backend and Celery workers (if used) are running.
- [ ] `.env` is configured with provider URLs, models and storage paths.
- [ ] Upstream self‑update governance is configured and tested.

See `docs/SECURITY.md` and `docs/DEPLOYMENT.md` for more details.